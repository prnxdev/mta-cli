addEventHandler("onResourceStart", function () 
  outputChatBox("[SERVER] {resourceName} started!")
end)