addEventHandler("onResourceStart", function () 
  outputChatBox("[CLIENT] {resourceName} started!")
end)