function restart(resourceName)
  resource = getResourceFromName(resourceName)
  if getResourceState(resource) == "running" then
    restartResource(resource)
  else
    startResource(resource)
  end
end